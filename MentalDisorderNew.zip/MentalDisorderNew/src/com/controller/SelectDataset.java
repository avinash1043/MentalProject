package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/SelectDataset")
public class SelectDataset extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public SelectDataset() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String dataset=request.getParameter("type");
		HttpSession dbtype=request.getSession();
		dbtype.setAttribute("dataset", dataset);
		response.sendRedirect("SelectUser.jsp");
		System.out.println(dataset);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		
	}

}
