package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.algorithms.Classifier;
import com.bean.ClassificationBean;

@WebServlet("/ClassificationController")
public class ClassificationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public ClassificationController() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession sess=request.getSession();
		Classifier classifier=new Classifier();
		ClassificationBean bean=new ClassificationBean();
		String msgAfterStemming=(String)sess.getAttribute("msgStemmingResult");
		bean=classifier.analyze(msgAfterStemming);
		sess.setAttribute("msg_positiveScore", bean.getPositiveScore());
		sess.setAttribute("msg_negativeScore", bean.getNegetiveScore());
		sess.setAttribute("msg_difference", bean.getDifference());
		sess.setAttribute("msg_camparitiveScore", bean.getCamparitiveScore());
		
		ClassificationBean reply_sbean=new ClassificationBean();	
		String replyAfterStemming=(String)sess.getAttribute("replyStemmingResult");
		reply_sbean=classifier.analyze(replyAfterStemming);
		sess.setAttribute("reply_positiveScore", reply_sbean.getPositiveScore());
		sess.setAttribute("reply_negativeScore", reply_sbean.getNegetiveScore());
		sess.setAttribute("reply_difference", reply_sbean.getDifference());
		sess.setAttribute("reply_camparitiveScore", reply_sbean.getCamparitiveScore());
		
		response.sendRedirect("Score.jsp");
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
