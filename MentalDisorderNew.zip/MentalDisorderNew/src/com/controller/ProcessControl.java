package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.connection.DBConnection;


@WebServlet("/ProcessControl")
public class ProcessControl extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public ProcessControl() 
    {
        super();
       
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		{
			String username=request.getParameter("username");
			System.out.println(username);
			HttpSession sess=request.getSession();
			String dataset=(String) sess.getAttribute("dataset");
			sess.setAttribute("uniqueID", request.getParameter("uniqueID"));
			Connection con=DBConnection.getConnection();
			Statement st;
			try 
			{
				int count=0;
				st = con.createStatement();
				ResultSet rs=st.executeQuery("select * from "+dataset+" where username='"+username+"' ");
				while(rs.next())
				{
					count++;
				}
				System.out.println(count);
				if(count>0)
				{
					sess.setAttribute("username", username);
					response.sendRedirect("FacebookHome.jsp");
				}
				else
				{
					PrintWriter out = response.getWriter();  
					response.setContentType("text/html");  
					out.println("<script type=\"text/javascript\">");  
					out.println("alert('Please enter correct username...');");
					out.println("location='SelectUser.jsp';");
					out.println("</script>");
				}
				
				
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			
		}
	}
}
