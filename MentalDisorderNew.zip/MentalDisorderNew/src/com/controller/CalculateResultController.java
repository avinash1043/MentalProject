package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.connection.DBConnection;

@WebServlet("/CalculateResultController")
public class CalculateResultController extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public CalculateResultController() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession sess=request.getSession();
		String dataset=(String)sess.getAttribute("dataset");
		String uniqueID=(String)sess.getAttribute("uniqueID");
		if(dataset.equalsIgnoreCase("facebook_userprofile"))
		{
			try 
			{
			String PR,SC,checklogin,checkPostLikes,checkFriendResquest,checktimeSpend,prediction;
			String source="Facebook";
			HttpSession resultSession=request.getSession();
			int msg_positiveScore=10;
			int msg_negativeScore=7;
			
			String username=(String)resultSession.getAttribute("username");
			int totalfriends = 0, totalpost = 0, totallikes = 0, friendrequest = 0, acceptrequest = 0, avgloginperday = 0, timeSpendperDay = 0, ag = 0,postperday=0;
			int resultCount=0;
			String gender=null;
			Connection con=DBConnection.getConnection();
			String NC=null,CRA=null,IO=null;
			Statement s=con.createStatement();
			s.executeUpdate("delete from tbl_results where username='"+username+"'");
			Statement smt=con.createStatement();
			ResultSet rs=smt.executeQuery("SELECT username, totalfriends, totalpost, totallikes, friendrequest, acceptrequest, avgloginperday, timeSpendperDay, age, totalpostperday,gender FROM facebook_userprofile where username='"+username+"'");
			while(rs.next())
			{
				totalfriends=rs.getInt(2);
				totalpost=rs.getInt(3);
				totallikes=rs.getInt(4);
				friendrequest=rs.getInt(5);
				acceptrequest=rs.getInt(6);
				avgloginperday=rs.getInt(7);
				timeSpendperDay=rs.getInt(8);
				ag=rs.getInt(9);
				postperday=rs.getInt(10);
				gender=rs.getString(11);
			}
			
			if(msg_positiveScore>msg_negativeScore )
			{
				PR="Normal";
			}
			else 
			{
				PR="Week";
				resultCount++;
			}
			
			//Predict Friendship between two persons
			if(msg_positiveScore>msg_negativeScore || msg_negativeScore>msg_positiveScore)
			{
				SC="OneSide";
				resultCount++;
			}
			else
			{
				SC="BothSide";
			}
			
			//Check Average login time
			if(avgloginperday>=10)
			{
				checklogin="Obsessed";
				resultCount++;
			}
			else
			{
				checklogin="Normal";
			}
			
			//Check total posts and likes
			if(totallikes<totalpost/3)
			{
				checkPostLikes="Obsessed";
				resultCount++;
			}
			else
			{
				checkPostLikes="Normal";
			}
			
			//Check total friend request send and total request accept
			if(acceptrequest<friendrequest/2)
			{
				checkFriendResquest="Obsessed";
				resultCount++;
			}
			else
			{
				checkFriendResquest="Normal";
			}
			
			//Check per day time spend on SN
			if(timeSpendperDay>6)
			{
				resultCount++;
				checktimeSpend="Obsessed";
			}
			else
			{
				checktimeSpend="Normal";
			}
			//Net compulsion
			if(checklogin.equalsIgnoreCase("Obsessed") && checkPostLikes.equalsIgnoreCase("Obsessed") && checktimeSpend.equalsIgnoreCase("Obsessed"))
			{
				NC="Obsessed";
			}
			else 
			{
				NC="Normal";
			}
			//Cyber Relationship Addiction
			if(PR.equalsIgnoreCase("Week") && acceptrequest<friendrequest/2)
			{
				CRA="Obsessed";
				
			}
			else 
			{
				CRA="Normal";
			}
			//Information Overload
			if(postperday>=20)
			{
				IO="Obsessed";
			}
			else 
			{
				IO="Normal";
			}
					
			
			if(resultCount>=3)
			{
				prediction="Obsessed User";
			}
			else
			{
				if(avgloginperday<=2 && timeSpendperDay>10 && totallikes<3 && totalpost<3 && totalfriends<10)
				{
					prediction="Heavy User";
				}
				else
				{
					prediction="Normal User";
				}
			}
			
			Statement st=con.createStatement();
			int c=st.executeUpdate("insert into tbl_results(username, PR, SC, checkAvgLogin, checkPostLikes, checkFriendRequest, checkTimeSpend, age, prediction,dataset,NC,CRA,IO,gender,uniqueID)values('"+username+"','"+PR+"','"+SC+"','"+checklogin+"','"+checkPostLikes+"','"+checkFriendResquest+"','"+checktimeSpend+"','"+ag+"','"+prediction+"','"+source+"','"+NC+"','"+CRA+"','"+IO+"','"+gender+"','"+uniqueID+"')");
			if(c>0)
			{
				PrintWriter out = response.getWriter();  
				response.setContentType("text/html");  
				out.println("<script type=\"text/javascript\">");  
				out.println("alert('Feature extracted & Prediction calculated successfully...');");
				out.println("location='Classification.jsp';");
				out.println("</script>");
			}
			else
			{
				PrintWriter out = response.getWriter();  
				response.setContentType("text/html");  
				out.println("<script type=\"text/javascript\">");  
				out.println("alert('Insertion problem..Please retry.');");
				out.println("location='Score.jsp';");
				out.println("</script>");
			}
			
			
			
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
