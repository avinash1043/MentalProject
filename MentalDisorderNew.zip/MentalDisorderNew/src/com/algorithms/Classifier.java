
package com.algorithms;

import java.util.ArrayList;
import java.util.List;

import com.bean.ClassificationBean;
public class Classifier 
{


	private int hits  = 0;
	private List<String> words = new ArrayList<String>();
	private List<String> adjectives = new ArrayList<String>();
	private String[] tokens;


	private void addPush(String t, int score){
		hits += score;
		words.add(t);
	}

	private void multiply(String t, int score){
		hits *= score;
		adjectives.add(t);
	}

	private void init( String phrase) 
	{
		hits  = 0;
		words = new ArrayList<String>();
		adjectives = new ArrayList<String>();

		String noPunctuation = phrase.replaceAll("[^a-zA-Z ]+", " ").replaceAll(" {2,}"," ");
		tokens = noPunctuation.toLowerCase().split(" ");		 
	}

	

	public Classification negativity( String phrase ) 
	{

		init(phrase);

		for(String t : tokens) {
			if (ClassificationStrings.neg5.indexOf(t) > -1) {
				addPush(t,5);
			} else if (ClassificationStrings.neg4.indexOf(t) > -1) {
				addPush(t,4);
			} else if (ClassificationStrings.neg3.indexOf(t) > -1) {
				addPush(t,3);
			} 
		}

		for(String t : tokens) {
			if (ClassificationStrings.int3.indexOf(t) > -1) {
				multiply(t, 4);
			} else if (ClassificationStrings.int2.indexOf(t) > -1) {
				multiply(t, 3);
			} else if (ClassificationStrings.int1.indexOf(t) > -1) {
				multiply(t, 2);
			}
		}
		
		return new Classification(hits, tokens.length, words, adjectives );

	}



	public Classification positivity( String phrase) {
		
		init(phrase);

		for(String t : tokens) {
			if (ClassificationStrings.pos5.indexOf(t) > -1) {
				addPush(t,5);
			} else if (ClassificationStrings.pos4.indexOf(t) > -1) {
				addPush(t,4);
			} else if (ClassificationStrings.pos3.indexOf(t) > -1) {
				addPush(t,3);
			} else if (ClassificationStrings.pos2.indexOf(t) > -1) {
				addPush(t,2);
			} else if (ClassificationStrings.pos1.indexOf(t) > -1) {
				addPush(t,1);
			}
		}

		for(String t : tokens) {
			if (ClassificationStrings.int3.indexOf(t) > -1) {
				multiply(t, 4);
			} else if (ClassificationStrings.int2.indexOf(t) > -1) {
				multiply(t, 3);
			} else if (ClassificationStrings.int1.indexOf(t) > -1) {
				multiply(t, 2);
			}
		}
		
		return new Classification(hits, tokens.length, words, adjectives );
	}


	

	public ClassificationBean analyze( String phrase ) 
	{
		ClassificationBean sbean=new ClassificationBean();
		Classification pos = positivity(phrase);
		Classification neg = negativity(phrase);
		sbean.setPositiveScore(pos.getScore());
		sbean.setNegetiveScore(neg.getScore());
		sbean.setDifference(pos.getScore() - neg.getScore());
		sbean.setCamparitiveScore(pos.getComparative() - neg.getComparative());
		return sbean;
		  
	}
	
}
