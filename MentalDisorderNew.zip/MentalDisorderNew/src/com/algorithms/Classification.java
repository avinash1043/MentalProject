/**
 * 
 */
package com.algorithms;

import java.util.List;

public class Classification {

	private int score;
	private double comparative;
	private List<String> words;
	private List<String> adjectives;
	private Classification positive, negative;

	public Classification(int hits, int length, List<String> words2, List<String> adjectives2 ) {
		this.score = hits;
		if( length != 0.0 ) {
			this.comparative = (double) hits / (double) length;
		} else {
			this.comparative = 0.0;
		}
		this.words       = words2;
		this.adjectives  = adjectives2;
	}

	public Classification(int hits, double d, Classification pos, Classification neg) {
		this.score = hits;
		this.comparative = d;
		this.positive = pos;
		this.negative = neg;
	}

	/**
	 * @return the score
	 */
	public int getScore() {
		return score;
	}

	/**
	 * @return the comparative
	 */
	public double getComparative() {
		return comparative;
	}

	/**
	 * 
	 * @return
	 */
	public List<String> getWords() {
		return this.words;
	}

	/**
	 * @return the adjectives
	 */
	public List<String> getAdjectives() {
		return adjectives;
	}

	/**
	 * @return the positive
	 */
	public Classification getPositive() {
		return positive;
	}

	/**
	 * @return the negative
	 */
	public Classification getNegative() {
		return negative;
	}

}
