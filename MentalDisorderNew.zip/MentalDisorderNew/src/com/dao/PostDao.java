package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import com.bean.Follower;
import com.bean.Tweet;
import com.bean.UserBean;
import com.connection.DBConnection;

public class PostDao {
	
	public boolean createTweet(Tweet twit) {
		
		boolean flag=false;
		String sql = "Insert into tbl_post values(?,?,?,?,?,?)";
		try {
			PreparedStatement pstmt = DBConnection.getConnection().prepareStatement(sql);
			pstmt.setInt(1, 0);
			pstmt.setString(2, twit.getMessage());
			pstmt.setBlob(3, twit.getUploadImg());
			pstmt.setString(4, twit.getUploadName());
			pstmt.setTimestamp(5, (Timestamp) twit.getTweetdate());
			pstmt.setString(6, twit.getName());
			int index = pstmt.executeUpdate();
			if(index>0){
				flag=true;
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return flag;
	}
	
	public ResultSet selectTweet() {
		
		ResultSet rs= null;
		String sql ="SELECT t.postid, t.message, t.uploadimg, t.uploadname, t.datetime, u.name,u.image,u.id"
				+" From tbl_post t, tbl_user u Where t.userid=u.id order by t.datetime desc";
		try {
			PreparedStatement pstmt = DBConnection.getConnection().prepareStatement(sql);
			rs = pstmt.executeQuery();			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return rs;
	}
	
	public ArrayList<UserBean> searchUser(String name, int userId) {
		
		ArrayList<UserBean> listUser = new ArrayList<UserBean>();
		String sql="Select id,name,address,image From tbl_user Where id <> ? AND name like ? ";
		try {
			PreparedStatement pstmt = DBConnection.getConnection().prepareStatement(sql);
			pstmt.setInt(1, userId);
			pstmt.setString(2, name +"%");
			
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()){
				UserBean user = new UserBean();
				user.setId(rs.getInt(1));
				user.setName(rs.getString(2));
				user.setAddress(rs.getString(3));
				user.setImage(rs.getBinaryStream(4));
				listUser.add(user);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return listUser;
	}
	
	public boolean sendRequest(Follower follower) {
		
		boolean flag = false;
		String sql = "Insert Into tbl_follower Values(?,?,?,?)";
		try {
			PreparedStatement pstmt = DBConnection.getConnection().prepareStatement(sql);
			pstmt.setInt(1, 0);
			pstmt.setInt(2, follower.getSender().getId());
			pstmt.setInt(3, follower.getReceiver().getId());
			pstmt.setTimestamp(4, new Timestamp(follower.getRequestDate().getTime()));
			int index = pstmt.executeUpdate();
			if(index>0){
				flag=true;
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return flag;
	}
	public ArrayList<Follower> selectFollowers(int userId) {
		ArrayList<Follower> followerList = new ArrayList<Follower>();
		String sql = "SELECT t.name, t.image, t.address, t.email, f.userid,f.followerid "
				+" FROM tbl_user t Inner Join tbl_follower f ON t.id=f.userid "
				+" WHERE f.followerid=?";
		try {
			PreparedStatement pstmt = DBConnection.getConnection().prepareStatement(sql);
			pstmt.setInt(1, userId);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()){
				UserBean user = new UserBean();
				user.setName(rs.getString(1));
				user.setImage(rs.getBinaryStream(2));
				user.setAddress(rs.getString(3));
				user.setEmail(rs.getString(4));
				user.setId(rs.getInt(5));
				
				UserBean user1 = new UserBean();
				user1.setId(rs.getInt(5));
				
				Follower follower = new Follower();
				follower.setSender(user);
				follower.setReceiver(user1);
				followerList.add(follower);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return followerList;
	}


	public ArrayList<Follower> selectFollowings(int userId) {
		
		ArrayList<Follower> followingList = new ArrayList<Follower>();
		String sql = "SELECT t.name, t.image, t.address, t.email,f.userid,f.followerid "
				+" FROM tbl_user t Inner Join tbl_follower f ON t.id=f.followerid "
				+" WHERE f.userid=?";
		try {
			PreparedStatement pstmt = DBConnection.getConnection().prepareStatement(sql);
			pstmt.setInt(1, userId);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()){
				UserBean user = new UserBean();
				user.setName(rs.getString(1));
				user.setImage(rs.getBinaryStream(2));
				user.setAddress(rs.getString(3));
				user.setEmail(rs.getString(4));
				user.setId(rs.getInt(5));
				
				UserBean user1 = new UserBean();
				user1.setId(rs.getInt(6));
				
				Follower follower = new Follower();
				follower.setSender(user);
				follower.setReceiver(user1);
				followingList.add(follower);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return followingList;
	}
	
	public ResultSet search(String name) {
		ResultSet rs=null;
		Connection con=DBConnection.getConnection();
		String sql = "Select * from tbl_user where email='"+name+"'";
		try {
			Statement stmt = con.createStatement();
		     rs = stmt.executeQuery(sql);
		return rs;
			}catch (Exception e) {
				e.printStackTrace();
			}
		return rs;
		
	}
	
	
	public int insertTokenData(UserBean bean) throws SQLException 
	{
		String sql="insert into tbl_token values(?,?,?,?)";
		
			System.out.println("in  insert data dao..");
			Connection con=DBConnection.getConnection();
			PreparedStatement pst=con.prepareStatement(sql);
			
			pst.setInt(1,bean.getId());
			pst.setString(2,bean.getName());
			pst.setString(3,bean.getEmail());
			pst.setString(4,bean.getToken());
		
			
			
			int i=pst.executeUpdate();
			System.out.println(" Token query done..");
			return i;
	}
	
	 

}
