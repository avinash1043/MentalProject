package com.bean;

public class ClassificationBean 
{
	int positiveScore,negetiveScore,difference;
	double camparitiveScore;
	public int getPositiveScore() {
		return positiveScore;
	}
	public void setPositiveScore(int positiveScore) {
		this.positiveScore = positiveScore;
	}
	public int getNegetiveScore() {
		return negetiveScore;
	}
	public void setNegetiveScore(int negetiveScore) {
		this.negetiveScore = negetiveScore;
	}
	public int getDifference() {
		return difference;
	}
	public void setDifference(int difference) {
		this.difference = difference;
	}
	public double getCamparitiveScore() {
		return camparitiveScore;
	}
	public void setCamparitiveScore(double camparitiveScore) {
		this.camparitiveScore = camparitiveScore;
	}

}
