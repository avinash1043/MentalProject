package com.bean;

import java.util.Date;


public class Follower {
	private int id;
	private UserBean sender;
	private UserBean receiver;
	private Date requestDate;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public UserBean getSender() {
		return sender;
	}
	public void setSender(UserBean sender) {
		this.sender = sender;
	}
	public UserBean getReceiver() {
		return receiver;
	}
	public void setReceiver(UserBean receiver) {
		this.receiver = receiver;
	}
	public Date getRequestDate() {
		return requestDate;
	}
	public void setRequestDate(Date requestDate) {
		this.requestDate = requestDate;
	}
	
}
