package com.bean;

public class RealStream {
	private int twitId;
	private String userName;
	private String postContent;
	private String result;
	private double resultProb;
	
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public double getResultProb() {
		return resultProb;
	}
	public void setResultProb(double resultProb) {
		this.resultProb = resultProb;
	}
	public int getTwitId() {
		return twitId;
	}
	public void setTwitId(int twitId) {
		this.twitId = twitId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPostContent() {
		return postContent;
	}
	public void setPostContent(String postContent) {
		this.postContent = postContent;
	}
	
	
}
